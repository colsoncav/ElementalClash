@echo off
title Elemental Clash
echo Launching Elemental Clash...
start "" "%~dp0index.html"
exit
